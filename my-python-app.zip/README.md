# 🐍 My Python App

Prosty projekt w Pythonie do celów edukacyjnych z pipeline CI/CD i testami jednostkowymi.

## 📁 Struktura katalogów

```
app/              # Kod źródłowy aplikacji
tests/            # Testy jednostkowe
.github/workflows # Konfiguracja GitHub Actions
```

## 🚀 Jak uruchomić

1. Zainstaluj zależności:
```bash
pip install -r requirements.txt
```

2. Uruchom aplikację:
```bash
python app/main.py
```

3. Uruchom testy:
```bash
pytest
```

## 🛠 Technologie

- Python 3.10+
- Pytest
- GitHub Actions (CI/CD)

## ⚖️ Licencja

Zobacz plik [LICENSE](LICENSE)

## 👥 Współtworzenie

Zasady współtworzenia opisane w [CONTRIBUTING.md](CONTRIBUTING.md)
