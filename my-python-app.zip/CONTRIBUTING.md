# 🧾 Zasady współtworzenia

Dziękujemy za chęć współpracy!

## 🔄 Proces pracy

1. Forkuj repozytorium
2. Twórz nową gałąź (`feature/nazwa-funkcji`)
3. Wprowadź zmiany
4. Zrób pull request do `main`

## ✅ Konwencja commitów

- `feat:` – nowa funkcja
- `fix:` – poprawka błędu
- `docs:` – dokumentacja
- `test:` – testy
- `chore:` – inne zmiany

## 💬 Styl kodowania

Stosuj się do konwencji PEP8 (dla Pythona). Formatowanie kodu: `black`, `isort`.
